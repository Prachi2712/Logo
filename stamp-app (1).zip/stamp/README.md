# Stamp

Batch logo placement for catalogues, carousels and product shots. Upload a multi-page PDF or a
folder of images, upload your logo once, pick a corner, export. The logo lands on every page in one
pass, at full resolution, with the original artwork untouched.

## Run it

```bash
npm install
npm start          # http://localhost:3000
```

Node 18 or newer. `npm run dev` restarts on file changes.

Set `SESSION_SECRET` in production — without it a random secret is generated at boot, so every
restart signs everybody out.

```bash
SESSION_SECRET="$(openssl rand -hex 32)" NODE_ENV=production npm start
```

## What's where

```
server/
  index.js      Express app, static hosting, error handler
  db.js         SQLite schema (users, projects, assets)
  auth.js       register / login / logout, bcrypt + JWT in an httpOnly cookie
  projects.js   project CRUD, multer uploads, owner-checked file serving
  export.js     the actual stamping — pdf-lib, runs server-side
public/
  index.html    landing + sign in / sign up
  app.html      workspace shell
  css/app.css   design tokens and components
  js/app.js     preview rendering, drag placement, autosave, export
data/           created on first run: stamp.db + uploads/ (gitignore this)
```

## How the stamping works

This is the part that matters, so it's worth being precise about it.

**Nothing is regenerated.** For PDF sources, `copyPages` lifts each original page into the output
document byte-for-byte and the logo is drawn on top as a separate embedded image object. Text stays
selectable, vector artwork stays vector, and the logo is exactly the PNG you uploaded — scaled by
the PDF viewer at display time, never resampled by us. That is why edges stay sharp where an
image-generation approach would soften or crop them.

**Placements are resolution-independent.** A placement is stored as `{x, y, w}` where x and y are
the logo's top-left corner as a fraction of the page's *visible* width and height, and w is the logo
width as a fraction of page width. The same preset therefore lands correctly on a 1080×1080 carousel
slide and an A4 page in the same batch.

**Rotated pages are handled.** A PDF page can carry a `/Rotate` flag, which means what you see in the
preview and what PDF user space thinks is "up" disagree. `toUserSpace()` in `server/export.js` maps
display coordinates into user space for 0/90/180/270 and returns the counter-rotation the logo needs
so it still reads upright. Most tools get this wrong and stamp sideways.

**Preset vs hand-placed.** Pages follow the preset until you drag one. A dragged page gets its own
entry with `custom: true`, shows an amber dot in the filmstrip, and survives preset changes until
you hit "Apply to every page".

## API

| Method | Path | Notes |
| --- | --- | --- |
| POST | `/api/auth/register` \| `/login` \| `/logout` | rate limited, 30 per 15 min |
| GET | `/api/auth/me` | current user or null |
| GET/POST | `/api/projects` | list, create |
| GET/PATCH/DELETE | `/api/projects/:id` | owner only |
| POST | `/api/projects/:id/assets` | multipart, `kind=source\|logo` |
| DELETE | `/api/assets/:id` | |
| GET | `/api/files/:id` | owner-checked; uploads are never on a public path |
| POST | `/api/projects/:id/export` | returns the stamped PDF |

## Known gaps

- SVG logos upload and preview but can't be embedded in a PDF directly — rasterise to PNG first, or
  add `svg2pdf` to the export path.
- No PNG/ZIP export yet; the client-side canvas path for that is straightforward to add back.
- Uploads go to local disk. Swap the `multer` storage for S3 before running this on more than one box.
- No password reset or email verification.
