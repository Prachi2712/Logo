const path = require("path");
const fs = require("fs");
const { PDFDocument, degrees } = require("pdf-lib");
const { UPLOAD_DIR } = require("./db");
const { requireUser } = require("./auth");
const { owned, assetsOf } = require("./projects");

/**
 * Placements are stored in display space: x / y are the logo's top-left corner
 * as a fraction of the page's visible width and height, w is the logo width as
 * a fraction of page width. A PDF page can carry a /Rotate flag, which means
 * display space and PDF user space disagree. This maps one to the other and
 * returns the counter-rotation the logo needs so it still reads upright.
 */
function toUserSpace(rot, mw, mh, dx, dy, w, h) {
  switch (((rot % 360) + 360) % 360) {
    case 90:  return { x: dy + h,    y: dx,      rotate: 90 };
    case 180: return { x: mw - dx,   y: dy + h,  rotate: 180 };
    case 270: return { x: mw - dy - h, y: mh - dx, rotate: 270 };
    default:  return { x: dx,        y: mh - dy - h, rotate: 0 };
  }
}

function defaultPlacement({ anchor, size, margin }, W, H, ratio) {
  const w = size / 100;
  const hFrac = (w * W * ratio) / H;
  const mx = margin / 100;
  const my = ((margin / 100) * W) / H;
  return {
    x: anchor.endsWith("l") ? mx : anchor.endsWith("c") ? (1 - w) / 2 : 1 - w - mx,
    y: anchor.startsWith("t") ? my : anchor.startsWith("m") ? (1 - hFrac) / 2 : 1 - hFrac - my,
    w,
  };
}

const read = (a) => fs.readFileSync(path.join(UPLOAD_DIR, a.stored_name));

function mount(app) {
  app.post("/api/projects/:id/export", requireUser, async (req, res) => {
    const project = owned(req.params.id, req.user.id);
    if (!project) return res.status(404).json({ error: "Project not found." });

    const assets = assetsOf(project.id);
    const sources = assets.filter((a) => a.kind === "source");
    const logoAsset = assets.find((a) => a.kind === "logo");

    if (!sources.length) return res.status(400).json({ error: "Add at least one file to stamp." });
    if (!logoAsset) return res.status(400).json({ error: "Add a logo before exporting." });
    if (logoAsset.mime === "image/svg+xml")
      return res.status(400).json({ error: "Upload the logo as PNG — SVG can’t be embedded directly." });

    const settings = { anchor: "br", size: 16, margin: 4, opacity: 100, ...JSON.parse(project.settings) };
    const placements = JSON.parse(project.placements);

    try {
      const out = await PDFDocument.create();
      out.setTitle(project.name);
      out.setProducer("Stamp");

      const logoBytes = read(logoAsset);
      const logo = /png/i.test(logoAsset.mime)
        ? await out.embedPng(logoBytes)
        : await out.embedJpg(logoBytes);
      const ratio = logo.height / logo.width;
      const opacity = Math.max(0.02, Math.min(1, settings.opacity / 100));

      for (const src of sources) {
        const bytes = read(src);

        if (src.mime === "application/pdf") {
          const donor = await PDFDocument.load(bytes, { ignoreEncryption: true });
          const indices = donor.getPageIndices();
          const copies = await out.copyPages(donor, indices);

          copies.forEach((copy, i) => {
            const page = out.addPage(copy); // original content passes through untouched
            const { width: mw, height: mh } = page.getSize();
            const rot = page.getRotation().angle;
            const W = rot % 180 === 0 ? mw : mh;
            const H = rot % 180 === 0 ? mh : mw;

            const place = placements[`${src.id}:${i + 1}`] || defaultPlacement(settings, W, H, ratio);
            const w = place.w * W;
            const h = w * ratio;
            const m = toUserSpace(rot, mw, mh, place.x * W, place.y * H, w, h);
            page.drawImage(logo, {
              x: m.x, y: m.y, width: w, height: h, opacity, rotate: degrees(m.rotate),
            });
          });
        } else {
          const img = /png/i.test(src.mime)
            ? await out.embedPng(bytes)
            : await out.embedJpg(bytes);
          const page = out.addPage([img.width, img.height]);
          page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });

          const place =
            placements[`${src.id}:1`] || defaultPlacement(settings, img.width, img.height, ratio);
          const w = place.w * img.width;
          const h = w * ratio;
          page.drawImage(logo, {
            x: place.x * img.width,
            y: img.height - place.y * img.height - h,
            width: w, height: h, opacity,
          });
        }
      }

      const pdf = await out.save();
      const file = (project.name || "stamped").replace(/[^\w\- ]+/g, "").trim() || "stamped";
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${file}.pdf"`);
      res.send(Buffer.from(pdf));
    } catch (err) {
      console.error("export failed", err);
      res.status(500).json({
        error: "Export failed. One of the files may be encrypted or damaged — remove it and try again.",
      });
    }
  });
}

module.exports = { mount };
