const path = require("path");
const express = require("express");
const cookieParser = require("cookie-parser");

const auth = require("./auth");
const projects = require("./projects");
const exporter = require("./export");

const app = express();
const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "..", "public");

app.disable("x-powered-by");
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use(auth.session);

auth.mount(app);
projects.mount(app);
exporter.mount(app);

app.use(express.static(PUBLIC, { extensions: ["html"] }));

app.get("/app", (req, res) =>
  req.user ? res.sendFile(path.join(PUBLIC, "app.html")) : res.redirect("/?next=/app")
);
app.get("/", (_req, res) => res.sendFile(path.join(PUBLIC, "index.html")));

// Multer and validation errors arrive here; keep the message, drop the stack.
app.use((err, _req, res, _next) => {
  const code = err.code === "LIMIT_FILE_SIZE" ? 413 : err.status || 400;
  console.error(err.message);
  res.status(code).json({
    error:
      err.code === "LIMIT_FILE_SIZE"
        ? "That file is over the 40 MB limit."
        : err.message || "Something went wrong.",
  });
});

app.listen(PORT, () => console.log(`Stamp running at http://localhost:${PORT}`));
