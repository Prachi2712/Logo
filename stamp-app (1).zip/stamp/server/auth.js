const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const { db } = require("./db");

const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const COOKIE = "stamp_session";
const MAX_AGE = 1000 * 60 * 60 * 24 * 14;

function issue(res, user) {
  const token = jwt.sign({ sub: user.id }, SECRET, { expiresIn: "14d" });
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: MAX_AGE,
  });
}

/** Attaches req.user when a valid session cookie is present. Never throws. */
function session(req, _res, next) {
  const token = req.cookies?.[COOKIE];
  if (token) {
    try {
      const { sub } = jwt.verify(token, SECRET);
      req.user = db.prepare("SELECT id, email, name FROM users WHERE id = ?").get(sub) || null;
    } catch {
      req.user = null;
    }
  }
  next();
}

/** Blocks the request unless signed in. */
function requireUser(req, res, next) {
  if (!req.user) return res.status(401).json({ error: "Sign in to continue." });
  next();
}

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true });

function mount(app) {
  app.post("/api/auth/register", limiter, async (req, res) => {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (name.length < 2) return res.status(400).json({ error: "Enter your name." });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))
      return res.status(400).json({ error: "That email address doesn’t look right." });
    if (password.length < 8)
      return res.status(400).json({ error: "Use at least 8 characters for your password." });

    const taken = db.prepare("SELECT 1 FROM users WHERE email = ?").get(email);
    if (taken) return res.status(409).json({ error: "An account already uses that email." });

    const user = { id: crypto.randomUUID(), email, name };
    db.prepare("INSERT INTO users (id, email, name, password_hash) VALUES (?,?,?,?)")
      .run(user.id, email, name, await bcrypt.hash(password, 12));

    issue(res, user);
    res.json({ user });
  });

  app.post("/api/auth/login", limiter, async (req, res) => {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const row = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

    // Same message either way, so the form can't be used to discover accounts.
    if (!row || !(await bcrypt.compare(password, row.password_hash)))
      return res.status(401).json({ error: "Email or password is incorrect." });

    const user = { id: row.id, email: row.email, name: row.name };
    issue(res, user);
    res.json({ user });
  });

  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie(COOKIE);
    res.json({ ok: true });
  });

  app.get("/api/auth/me", (req, res) => res.json({ user: req.user || null }));
}

module.exports = { session, requireUser, mount };
