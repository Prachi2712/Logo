const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const { PDFDocument } = require("pdf-lib");
const { db, UPLOAD_DIR } = require("./db");
const { requireUser } = require("./auth");

const ALLOWED = new Set([
  "application/pdf", "image/png", "image/jpeg", "image/webp", "image/svg+xml",
]);

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) =>
      cb(null, crypto.randomUUID() + path.extname(file.originalname).slice(0, 10)),
  }),
  limits: { fileSize: 40 * 1024 * 1024, files: 60 },
  fileFilter: (_req, file, cb) =>
    ALLOWED.has(file.mimetype)
      ? cb(null, true)
      : cb(new Error("Only PDF, PNG, JPEG, WebP and SVG files can be added.")),
});

const owned = (id, userId) =>
  db.prepare("SELECT * FROM projects WHERE id = ? AND user_id = ?").get(id, userId);

const assetsOf = (projectId) =>
  db.prepare("SELECT * FROM assets WHERE project_id = ? ORDER BY kind, sort_order, created_at").all(projectId);

function shape(project) {
  const assets = assetsOf(project.id);
  return {
    id: project.id,
    name: project.name,
    settings: JSON.parse(project.settings),
    placements: JSON.parse(project.placements),
    updatedAt: project.updated_at,
    sources: assets.filter((a) => a.kind === "source").map(pub),
    logo: assets.filter((a) => a.kind === "logo").map(pub)[0] || null,
  };
}

const pub = (a) => ({
  id: a.id, name: a.name, mime: a.mime, bytes: a.bytes,
  pageCount: a.page_count, url: `/api/files/${a.id}`,
});

async function pageCountOf(file) {
  if (file.mimetype !== "application/pdf") return 1;
  try {
    const doc = await PDFDocument.load(fs.readFileSync(file.path), { ignoreEncryption: true });
    return doc.getPageCount();
  } catch {
    return 1;
  }
}

function mount(app) {
  app.get("/api/projects", requireUser, (req, res) => {
    const rows = db
      .prepare("SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC")
      .all(req.user.id);
    res.json({ projects: rows.map(shape) });
  });

  app.post("/api/projects", requireUser, (req, res) => {
    const id = crypto.randomUUID();
    const name = String(req.body.name || "Untitled project").trim().slice(0, 80) || "Untitled project";
    const settings = JSON.stringify({ anchor: "br", size: 16, margin: 4, opacity: 100, rotation: 0 });
    db.prepare("INSERT INTO projects (id, user_id, name, settings) VALUES (?,?,?,?)")
      .run(id, req.user.id, name, settings);
    res.json({ project: shape(owned(id, req.user.id)) });
  });

  app.get("/api/projects/:id", requireUser, (req, res) => {
    const p = owned(req.params.id, req.user.id);
    if (!p) return res.status(404).json({ error: "Project not found." });
    res.json({ project: shape(p) });
  });

  app.patch("/api/projects/:id", requireUser, (req, res) => {
    const p = owned(req.params.id, req.user.id);
    if (!p) return res.status(404).json({ error: "Project not found." });

    const name = req.body.name !== undefined ? String(req.body.name).trim().slice(0, 80) : p.name;
    const settings = req.body.settings ? JSON.stringify(req.body.settings) : p.settings;
    const placements = req.body.placements ? JSON.stringify(req.body.placements) : p.placements;

    db.prepare(
      "UPDATE projects SET name=?, settings=?, placements=?, updated_at=datetime('now') WHERE id=?"
    ).run(name || p.name, settings, placements, p.id);
    res.json({ project: shape(owned(p.id, req.user.id)) });
  });

  app.delete("/api/projects/:id", requireUser, (req, res) => {
    const p = owned(req.params.id, req.user.id);
    if (!p) return res.status(404).json({ error: "Project not found." });
    for (const a of assetsOf(p.id)) fs.rmSync(path.join(UPLOAD_DIR, a.stored_name), { force: true });
    db.prepare("DELETE FROM projects WHERE id = ?").run(p.id);
    res.json({ ok: true });
  });

  app.post("/api/projects/:id/assets", requireUser, upload.array("files", 60), async (req, res) => {
    const p = owned(req.params.id, req.user.id);
    if (!p) return res.status(404).json({ error: "Project not found." });

    const kind = req.body.kind === "logo" ? "logo" : "source";
    if (kind === "logo") {
      for (const old of assetsOf(p.id).filter((a) => a.kind === "logo")) {
        fs.rmSync(path.join(UPLOAD_DIR, old.stored_name), { force: true });
        db.prepare("DELETE FROM assets WHERE id = ?").run(old.id);
      }
    }

    const start = db
      .prepare("SELECT COALESCE(MAX(sort_order), -1) + 1 AS n FROM assets WHERE project_id = ? AND kind = ?")
      .get(p.id, kind).n;

    const files = (req.files || []).sort((a, b) =>
      a.originalname.localeCompare(b.originalname, undefined, { numeric: true })
    );

    const insert = db.prepare(
      "INSERT INTO assets (id, project_id, kind, name, stored_name, mime, bytes, page_count, sort_order) VALUES (?,?,?,?,?,?,?,?,?)"
    );
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      insert.run(crypto.randomUUID(), p.id, kind, f.originalname, f.filename, f.mimetype, f.size,
        await pageCountOf(f), start + i);
    }

    db.prepare("UPDATE projects SET updated_at = datetime('now') WHERE id = ?").run(p.id);
    res.json({ project: shape(owned(p.id, req.user.id)) });
  });

  app.delete("/api/assets/:id", requireUser, (req, res) => {
    const a = db
      .prepare(
        `SELECT assets.* FROM assets JOIN projects ON projects.id = assets.project_id
         WHERE assets.id = ? AND projects.user_id = ?`
      )
      .get(req.params.id, req.user.id);
    if (!a) return res.status(404).json({ error: "File not found." });
    fs.rmSync(path.join(UPLOAD_DIR, a.stored_name), { force: true });
    db.prepare("DELETE FROM assets WHERE id = ?").run(a.id);
    res.json({ ok: true });
  });

  // Files are served only to their owner — uploads never sit on a public path.
  app.get("/api/files/:id", requireUser, (req, res) => {
    const a = db
      .prepare(
        `SELECT assets.* FROM assets JOIN projects ON projects.id = assets.project_id
         WHERE assets.id = ? AND projects.user_id = ?`
      )
      .get(req.params.id, req.user.id);
    if (!a) return res.sendStatus(404);
    res.type(a.mime);
    res.setHeader("Cache-Control", "private, max-age=86400");
    fs.createReadStream(path.join(UPLOAD_DIR, a.stored_name)).pipe(res);
  });
}

module.exports = { mount, owned, assetsOf };
