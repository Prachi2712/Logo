/* =============================================================
   Stamp — workspace client
   ============================================================= */
pdfjsLib.GlobalWorkerOptions.workerSrc =
  "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

const $ = (id) => document.getElementById(id);

const S = {
  user: null,
  project: null,
  pages: [],        // {assetId, name, pageNo, key, W, H, doc?, img?, thumb?, full?}
  placements: {},   // key -> {x, y, w, custom}
  settings: { anchor: "br", size: 16, margin: 4, opacity: 100 },
  logo: null,       // {url, ratio, w, h}
  sel: 0,
  zoom: 0,          // 0 = fit
};

/* ---------------- api ---------------- */
async function api(url, opts = {}) {
  const res = await fetch(url, {
    credentials: "same-origin",
    headers: opts.body instanceof FormData ? {} : { "Content-Type": "application/json" },
    ...opts,
  });
  if (res.status === 401) { location.href = "/?next=/app"; throw new Error("signed out"); }
  const data = res.headers.get("content-type")?.includes("json") ? await res.json() : null;
  if (!res.ok) throw new Error(data?.error || "Request failed.");
  return data;
}

/* ---------------- toasts + modals ---------------- */
function toast(msg, kind = "ok") {
  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.innerHTML = `<svg class="i sm"><use href="#ic-${kind === "ok" ? "check" : "alert"}"/></svg><span></span>`;
  el.querySelector("span").textContent = msg;
  $("toasts").appendChild(el);
  setTimeout(() => el.remove(), 3600);
}
const openModal = (id) => $(id).classList.add("open");
const closeModal = (id) => $(id).classList.remove("open");
document.addEventListener("click", (e) => {
  if (e.target.matches("[data-close]") || e.target.closest("[data-close]"))
    e.target.closest(".scrim")?.classList.remove("open");
  if (e.target.classList.contains("scrim")) e.target.classList.remove("open");
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") document.querySelectorAll(".scrim.open").forEach((s) => s.classList.remove("open"));
});

function confirmAction(title, body, label, fn) {
  $("confirmTitle").textContent = title;
  $("confirmBody").textContent = body;
  $("confirmGo").textContent = label;
  $("confirmGo").onclick = () => { closeModal("confirmScrim"); fn(); };
  openModal("confirmScrim");
}

/* ---------------- boot ---------------- */
(async function boot() {
  const { user } = await api("/api/auth/me");
  if (!user) return (location.href = "/?next=/app");
  S.user = user;
  $("btnAvatar").textContent = user.name.trim()[0].toUpperCase();
  $("userEmail").textContent = user.email;

  const { projects } = await api("/api/projects");
  const project = projects[0] || (await api("/api/projects", { method: "POST", body: JSON.stringify({ name: "Untitled project" }) })).project;
  await loadProject(project);
})();

async function loadProject(project) {
  S.project = project;
  S.settings = { ...S.settings, ...project.settings };
  S.placements = project.placements || {};
  S.sel = 0;
  $("projectName").value = project.name;

  syncControls();
  await loadLogo(project.logo);
  await buildPages(project.sources);
  renderFilmstrip();
  renderStage();
}

function syncControls() {
  $("size").value = S.settings.size;   $("sizeOut").textContent = S.settings.size + "%";
  $("margin").value = S.settings.margin; $("marginOut").textContent = S.settings.margin + "%";
  $("opacity").value = S.settings.opacity; $("opacityOut").textContent = S.settings.opacity + "%";
  document.querySelectorAll("#grid9 button").forEach((b) =>
    b.classList.toggle("on", b.dataset.a === S.settings.anchor));
}

async function loadLogo(asset) {
  if (!asset) {
    S.logo = null; $("logoCard").hidden = true; return;
  }
  const img = await new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => res(i); i.onerror = rej; i.src = asset.url;
  });
  S.logo = { url: asset.url, el: img, w: img.naturalWidth, h: img.naturalHeight, ratio: img.naturalHeight / img.naturalWidth };
  $("logoCard").hidden = false;
  $("logoImg").src = asset.url;
  $("logoName").textContent = asset.name;
  $("logoDims").textContent = `${img.naturalWidth} × ${img.naturalHeight} px`;
}

/* ---------------- pages ---------------- */
async function buildPages(sources) {
  S.pages = [];
  renderFileList(sources);

  for (const src of sources) {
    if (src.mime === "application/pdf") {
      const doc = await pdfjsLib.getDocument({ url: src.url, withCredentials: true }).promise;
      for (let n = 1; n <= doc.numPages; n++) {
        const page = await doc.getPage(n);
        const vp = page.getViewport({ scale: 1 }); // already accounts for /Rotate
        S.pages.push({ assetId: src.id, name: src.name, pageNo: n, key: `${src.id}:${n}`,
                       W: vp.width, H: vp.height, doc });
      }
    } else {
      const img = await new Promise((res, rej) => {
        const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src.url;
      });
      S.pages.push({ assetId: src.id, name: src.name, pageNo: 1, key: `${src.id}:1`,
                     W: img.naturalWidth, H: img.naturalHeight, img });
    }
  }

  // Drop placements whose page no longer exists.
  const live = new Set(S.pages.map((p) => p.key));
  for (const k of Object.keys(S.placements)) if (!live.has(k)) delete S.placements[k];

  updateSummary();
}

function renderFileList(sources) {
  const list = $("fileList");
  list.innerHTML = "";
  for (const s of sources) {
    const row = document.createElement("div");
    row.className = "file";
    row.innerHTML = `
      <div class="tag"><svg class="i sm"><use href="#ic-${s.mime === "application/pdf" ? "file" : "image"}"/></svg></div>
      <div class="meta"><b></b><span>${s.pageCount} page${s.pageCount === 1 ? "" : "s"} · ${(s.bytes / 1024 / 1024).toFixed(1)} MB</span></div>
      <button class="x" title="Remove"><svg class="i sm"><use href="#ic-x"/></svg></button>`;
    row.querySelector("b").textContent = s.name;
    row.querySelector(".x").onclick = () =>
      confirmAction("Remove this file?", `${s.name} and its placements leave this project.`, "Remove", async () => {
        await api(`/api/assets/${s.id}`, { method: "DELETE" });
        await refresh();
        toast("File removed.");
      });
    list.appendChild(row);
  }
}

async function refresh() {
  const { project } = await api(`/api/projects/${S.project.id}`);
  project.placements = S.placements; // keep unsaved drags
  await loadProject(project);
}

/* ---------------- placement maths ---------------- */
function presetFor(page) {
  const { anchor, size, margin } = S.settings;
  const ratio = S.logo ? S.logo.ratio : 0.35;
  const w = size / 100;
  const hFrac = (w * page.W * ratio) / page.H;
  const mx = margin / 100;
  const my = ((margin / 100) * page.W) / page.H;
  return {
    x: anchor.endsWith("l") ? mx : anchor.endsWith("c") ? (1 - w) / 2 : 1 - w - mx,
    y: anchor.startsWith("t") ? my : anchor.startsWith("m") ? (1 - hFrac) / 2 : 1 - hFrac - my,
    w, custom: false,
  };
}
const placementFor = (page) => S.placements[page.key] || presetFor(page);

function updateSummary() {
  const moved = Object.values(S.placements).filter((p) => p.custom).length;
  $("sumPages").textContent = S.pages.length
    ? `${S.pages.length} page${S.pages.length === 1 ? "" : "s"}` : "No pages yet";
  $("sumMoved").textContent = moved ? `${moved} hand-placed` : "All on preset";
  $("movedNote").hidden = moved === 0;
  if (moved) $("movedText").textContent =
    `${moved} page${moved === 1 ? " has" : "s have"} a hand-placed logo. Applying to every page overwrites ${moved === 1 ? "it" : "them"}.`;
  const cur = S.pages[S.sel];
  $("btnResetOne").hidden = !(cur && S.placements[cur.key]?.custom);
  const ready = S.pages.length && S.logo;
  $("btnExport").disabled = !ready;
  $("btnExportTop").disabled = !ready;
}

/* ---------------- rendering ---------------- */
async function renderPageCanvas(page, maxPx) {
  const scale = Math.min(maxPx / page.W, maxPx / page.H, 4);
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(page.W * scale));
  c.height = Math.max(1, Math.round(page.H * scale));
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  if (page.doc) {
    const p = await page.doc.getPage(page.pageNo);
    await p.render({ canvasContext: ctx, viewport: p.getViewport({ scale }) }).promise;
  } else {
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(page.img, 0, 0, c.width, c.height);
  }
  return c;
}

async function renderFilmstrip() {
  const strip = $("filmstrip");
  strip.innerHTML = "";
  for (let i = 0; i < S.pages.length; i++) {
    const page = S.pages[i];
    const btn = document.createElement("button");
    btn.className = "frame" + (i === S.sel ? " on" : "");
    btn.title = `${page.name} — page ${page.pageNo}`;
    btn.onclick = () => { S.sel = i; renderStage(); markFilmstrip(); };
    strip.appendChild(btn);

    if (!page.thumb) page.thumb = await renderPageCanvas(page, 170);
    const view = document.createElement("canvas");
    view.width = page.thumb.width; view.height = page.thumb.height;
    const ctx = view.getContext("2d");
    ctx.drawImage(page.thumb, 0, 0);
    stamp(ctx, view, placementFor(page));
    btn.appendChild(view);

    const tag = document.createElement("i"); tag.textContent = i + 1; btn.appendChild(tag);
    if (S.placements[page.key]?.custom) btn.appendChild(document.createElement("b"));
  }
}
function markFilmstrip() {
  [...$("filmstrip").children].forEach((el, i) => el.classList.toggle("on", i === S.sel));
}

function stamp(ctx, canvas, place) {
  if (!S.logo) return;
  const w = place.w * canvas.width;
  ctx.save();
  ctx.globalAlpha = S.settings.opacity / 100;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(S.logo.el, place.x * canvas.width, place.y * canvas.height, w, w * S.logo.ratio);
  ctx.restore();
}

async function renderStage() {
  const wrap = $("canvasWrap");
  if (!S.pages.length) {
    wrap.innerHTML = "";
    wrap.appendChild($("emptyState"));
    $("emptyState").style.display = "";
    $("stageLabel").textContent = "No page selected";
    updateSummary();
    return;
  }
  const page = S.pages[Math.min(S.sel, S.pages.length - 1)];
  S.sel = S.pages.indexOf(page);
  $("stageLabel").textContent = `${page.name} · page ${page.pageNo} of ${S.pages.length}`;

  if (!page.full) page.full = await renderPageCanvas(page, 1600);

  const box = wrap.getBoundingClientRect();
  const fit = Math.min((box.width - 52) / page.W, (box.height - 52) / page.H, 1.6);
  const scale = S.zoom || fit;
  $("zoomVal").textContent = S.zoom ? Math.round(scale * 100) + "%" : "Fit";

  const sheet = document.createElement("div");
  sheet.className = "sheet";
  sheet.style.width = page.W * scale + "px";
  sheet.style.height = page.H * scale + "px";

  const view = document.createElement("canvas");
  view.width = page.full.width; view.height = page.full.height;
  view.style.width = "100%"; view.style.height = "100%";
  view.getContext("2d").drawImage(page.full, 0, 0);
  sheet.appendChild(view);

  if (S.logo) {
    const place = placementFor(page);
    const handle = document.createElement("div");
    handle.className = "handle";
    handle.innerHTML = `<img src="${S.logo.url}" alt=""><span class="grip"></span>`;
    handle.querySelector("img").style.opacity = S.settings.opacity / 100;
    const put = (p) => {
      handle.style.left = p.x * 100 + "%";
      handle.style.top = p.y * 100 + "%";
      handle.style.width = p.w * 100 + "%";
      handle.style.height = (p.w * page.W * S.logo.ratio) / page.H * 100 + "%";
    };
    put(place);
    dragAndResize(handle, sheet, page, put);
    sheet.appendChild(handle);
  }

  wrap.innerHTML = "";
  wrap.appendChild(sheet);
  updateSummary();
}

function dragAndResize(handle, sheet, page, put) {
  let mode = null, start = null;

  const begin = (e, kind) => {
    e.preventDefault(); e.stopPropagation();
    handle.setPointerCapture(e.pointerId);
    handle.classList.add("drag");
    mode = kind;
    const r = sheet.getBoundingClientRect();
    const p = { ...placementFor(page) };
    start = { px: e.clientX, py: e.clientY, r, p };
  };

  handle.addEventListener("pointerdown", (e) =>
    begin(e, e.target.classList.contains("grip") ? "resize" : "move"));

  handle.addEventListener("pointermove", (e) => {
    if (!mode) return;
    const { r, p, px, py } = start;
    const dx = (e.clientX - px) / r.width;
    const dy = (e.clientY - py) / r.height;
    const next = { ...p, custom: true };

    if (mode === "move") {
      const h = (p.w * page.W * S.logo.ratio) / page.H;
      next.x = Math.max(0, Math.min(1 - p.w, p.x + dx));
      next.y = Math.max(0, Math.min(1 - h, p.y + dy));
    } else {
      next.w = Math.max(0.02, Math.min(1 - p.x, p.w + dx));
    }
    S.placements[page.key] = next;
    put(next);
  });

  const end = () => {
    if (!mode) return;
    mode = null;
    handle.classList.remove("drag");
    save(); renderFilmstrip(); updateSummary();
  };
  handle.addEventListener("pointerup", end);
  handle.addEventListener("pointercancel", end);
}

/* ---------------- saving ---------------- */
let saveTimer;
function save() {
  $("savedFlag").classList.remove("on");
  $("savedFlag").lastChild.textContent = "Saving…";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try {
      await api(`/api/projects/${S.project.id}`, {
        method: "PATCH",
        body: JSON.stringify({
          name: $("projectName").value,
          settings: S.settings,
          placements: S.placements,
        }),
      });
      $("savedFlag").classList.add("on");
      $("savedFlag").lastChild.textContent = "Saved";
    } catch (err) {
      $("savedFlag").lastChild.textContent = "Not saved";
      toast(err.message, "err");
    }
  }, 600);
}

/* ---------------- uploads ---------------- */
function uploadWith(input, kind) {
  input.onchange = () => { if (input.files.length) send([...input.files], kind); input.value = ""; };
}
function dropTarget(zone, kind) {
  ["dragenter", "dragover"].forEach((t) =>
    zone.addEventListener(t, (e) => { e.preventDefault(); zone.classList.add("over"); }));
  ["dragleave", "drop"].forEach((t) =>
    zone.addEventListener(t, (e) => { e.preventDefault(); zone.classList.remove("over"); }));
  zone.addEventListener("drop", (e) => {
    if (e.dataTransfer.files.length) send([...e.dataTransfer.files], kind);
  });
}

async function send(files, kind) {
  const form = new FormData();
  form.append("kind", kind);
  files.forEach((f) => form.append("files", f));

  $("upTitle").textContent = kind === "logo" ? "Uploading logo" : `Uploading ${files.length} file${files.length === 1 ? "" : "s"}`;
  $("upSub").textContent = "Your files stay private to your account.";
  $("upBar").style.width = "8%";
  openModal("uploadScrim");

  try {
    await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `/api/projects/${S.project.id}/assets`);
      xhr.withCredentials = true;
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) $("upBar").style.width = Math.max(8, (e.loaded / e.total) * 92) + "%";
      };
      xhr.onload = () => {
        $("upBar").style.width = "100%";
        if (xhr.status >= 200 && xhr.status < 300) resolve();
        else { try { reject(new Error(JSON.parse(xhr.responseText).error)); } catch { reject(new Error("Upload failed.")); } }
      };
      xhr.onerror = () => reject(new Error("Upload failed — check your connection."));
      xhr.send(form);
    });
    await refresh();
    toast(kind === "logo" ? "Logo applied to every page." : "Files added.");
  } catch (err) {
    toast(err.message, "err");
  } finally {
    setTimeout(() => closeModal("uploadScrim"), 250);
  }
}

uploadWith($("fileInput"), "source");
uploadWith($("logoInput"), "logo");
dropTarget($("dropFiles"), "source");
dropTarget($("dropLogo"), "logo");

/* ---------------- controls ---------------- */
$("rail").onclick = (e) => {
  const b = e.target.closest("button[data-tab]"); if (!b) return;
  document.querySelectorAll("#rail button").forEach((x) => x.classList.toggle("on", x === b));
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.tab === b.dataset.tab));
  $("panel").classList.remove("hide");
};

$("grid9").onclick = (e) => {
  const b = e.target.closest("button"); if (!b) return;
  S.settings.anchor = b.dataset.a;
  syncControls(); applyPreset(false);
};

function bindRange(id, key, suffix = "%") {
  $(id).oninput = () => {
    S.settings[key] = +$(id).value;
    $(id + "Out").textContent = $(id).value + suffix;
    applyPreset(false);
  };
}
bindRange("size", "size");
bindRange("margin", "margin");
bindRange("opacity", "opacity");

function applyPreset(force) {
  if (force) S.placements = {};
  else for (const page of S.pages) if (!S.placements[page.key]?.custom) delete S.placements[page.key];
  save(); renderStage(); renderFilmstrip();
}

$("btnApplyAll").onclick = () => { applyPreset(true); toast("Preset applied to every page."); };
$("btnResetOne").onclick = () => {
  delete S.placements[S.pages[S.sel].key];
  applyPreset(false);
};
$("btnRemoveLogo").onclick = () => {
  confirmAction("Remove the logo?", "Placements stay, so a new logo drops straight into them.", "Remove", async () => {
    await api(`/api/assets/${S.project.logo.id}`, { method: "DELETE" });
    await refresh(); toast("Logo removed.");
  });
};
$("projectName").oninput = save;

$("zoomIn").onclick = () => { S.zoom = Math.min((S.zoom || 0.6) * 1.25, 4); renderStage(); };
$("zoomOut").onclick = () => {
  S.zoom = (S.zoom || 0.6) / 1.25;
  if (S.zoom < 0.12) S.zoom = 0;
  renderStage();
};

/* ---------------- projects + account ---------------- */
$("btnAvatar").onclick = (e) => { e.stopPropagation(); $("userMenu").classList.toggle("open"); };
document.addEventListener("click", () => $("userMenu").classList.remove("open"));

$("btnLogout").onclick = async () => {
  await api("/api/auth/logout", { method: "POST" });
  location.href = "/";
};
$("btnDeleteProject").onclick = () =>
  confirmAction("Delete this project?", "Its files, logo and placements are removed for good.", "Delete", async () => {
    await api(`/api/projects/${S.project.id}`, { method: "DELETE" });
    location.reload();
  });

$("btnProjects").onclick = async () => {
  const { projects } = await api("/api/projects");
  const list = $("projectList");
  list.innerHTML = "";
  for (const p of projects) {
    const row = document.createElement("button");
    row.className = "project-row";
    row.innerHTML = `<div class="tag" style="width:30px;height:30px;border-radius:6px;display:grid;place-items:center;background:var(--raise);color:var(--muted)">
        <svg class="i sm"><use href="#ic-folder"/></svg></div>
      <div class="meta"><b></b><span>${p.sources.length} file${p.sources.length === 1 ? "" : "s"} · edited ${p.updatedAt.replace("T", " ").slice(0, 16)}</span></div>`;
    row.querySelector("b").textContent = p.name;
    row.onclick = async () => { closeModal("projectsScrim"); await loadProject(p); toast(`Opened ${p.name}.`); };
    list.appendChild(row);
  }
  openModal("projectsScrim");
};

$("btnNewProject").onclick = async () => {
  const { project } = await api("/api/projects", { method: "POST", body: JSON.stringify({ name: "Untitled project" }) });
  closeModal("projectsScrim");
  await loadProject(project);
  $("projectName").focus(); $("projectName").select();
};

/* ---------------- export ---------------- */
async function exportPdf() {
  $("upTitle").textContent = "Building your PDF";
  $("upSub").textContent = "Copying each page through and laying the logo on top.";
  $("upBar").style.width = "35%";
  openModal("uploadScrim");
  try {
    await new Promise((r) => setTimeout(r, 80)); // let the last autosave land
    const res = await fetch(`/api/projects/${S.project.id}/export`, {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json" }, body: "{}",
    });
    if (!res.ok) throw new Error((await res.json()).error || "Export failed.");
    $("upBar").style.width = "100%";
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = ($("projectName").value || "stamped").replace(/[^\w\- ]+/g, "").trim() + ".pdf";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    toast("PDF downloaded.");
  } catch (err) {
    toast(err.message, "err");
  } finally {
    setTimeout(() => closeModal("uploadScrim"), 250);
  }
}
$("btnExport").onclick = exportPdf;
$("btnExportTop").onclick = exportPdf;

let resizeTimer;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (S.pages.length) renderStage(); }, 150);
});
